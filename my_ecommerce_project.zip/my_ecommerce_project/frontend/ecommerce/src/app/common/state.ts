export class State {
  id: number;
  name: string;
}
